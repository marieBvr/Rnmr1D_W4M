#' Docopt command line specification
#' 
#' docopt helps you to define an interface for your command-line app, and
#' automatically generate a parser for it.
#' 
#' For more information see http://docopt.org
#' 
#' @name docopt-package
#' @docType package
{}
